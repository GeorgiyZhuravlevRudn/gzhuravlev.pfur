#!/bin/bash
cd /usr/share/man/man1
command=""
echo command that u need:
less  $command*

