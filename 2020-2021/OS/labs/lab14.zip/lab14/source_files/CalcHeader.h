#include<string>
#ifndef CalcHeader_H
#define CalcHeader_H
void OperationTypes();
std::string operation();
double Calculate(int variable_number);
int NumofVar();
#endif
