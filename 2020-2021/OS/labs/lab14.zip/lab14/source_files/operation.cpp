#include <iostream>
#include <string>
#include "CalcHeader.h"
using namespace std;
string operation() {
	string operation;
	cout << "operator: "; cin >> operation;
	return operation;
}