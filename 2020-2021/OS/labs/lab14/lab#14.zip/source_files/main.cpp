#include <iostream>
#include "CalcHeader.h"
int main()
{
	OperationTypes();
	Calculate(NumofVar());
	return 0;
}