# Задание №4 в-1
n1 = int(input('the price of sweeties for 1 kg: '))

for i in range(1, 11):
       print("the price of", i, "kg = ", n1*i)
